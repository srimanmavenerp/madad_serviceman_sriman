enum HtmlType { termsAndCondition, aboutUs, privacyPolicy, refundPolicy, returnPolicy, cancellationPolicy}
enum SendOtpType {forgetPassword, firebase, verification}
enum NoDataType { notification, booking, others}
enum BooingListStatus{completed,pending}  //Balu
enum BookingDetailsTabControllerState {bookingDetails,status}
enum EarningType{monthly, yearly}
enum EditProfileTabControllerState {generalInfo,accountIno}
enum ToasterMessageType {success, error, info}