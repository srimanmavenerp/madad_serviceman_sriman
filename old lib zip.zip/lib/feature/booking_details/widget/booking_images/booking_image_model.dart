class GetImagesResponse {
  final bool isSuccess;
  final String bookingId;
  final String date; // Changed to String to match API response
  final List<ImageDetails> imageDetails;

  GetImagesResponse({
    required this.isSuccess,
    required this.bookingId,
    required this.date,
    required this.imageDetails,
  });

  factory GetImagesResponse.fromJson(Map<String, dynamic> json) {
    print('Parsing GetImagesResponse: $json'); // Debug response
    return GetImagesResponse(
      isSuccess: json['success'] ?? false,
      bookingId: json['booking_id']?.toString() ?? '',
      date: json['date']?.toString() ?? '',
      imageDetails: (json['events'] as List<dynamic>? ?? [])
          .map((item) => ImageDetails.fromJson(item as Map<String, dynamic>))
          .toList(),
    );
  }
}

class ImageDetails {
  final String date;
  final String status;
  final String label;
  final String color;
  final List<String>? images; // Renamed from afterImages to images
  final List<String>? beforeimages; // Renamed from beforeImages to beforeimages
  final String note;
  final String updatedAt;
  final String? beforeImagesUploadedAt;
  final String? afterImagesUploadedAt;

  ImageDetails({
    required this.date,
    required this.status,
    required this.label,
    required this.color,
    this.images,
    this.beforeimages,
    required this.note,
    required this.updatedAt,
    this.beforeImagesUploadedAt,
    this.afterImagesUploadedAt,
  });

  factory ImageDetails.fromJson(Map<String, dynamic> json) {
    print('Parsing ImageDetails: $json'); // Debug individual item
    return ImageDetails(
      date: json['date']?.toString() ?? '',
      status: json['status']?.toString() ?? '',
      label: json['label']?.toString() ?? '',
      color: json['color']?.toString() ?? '#4CAF50',
      images: json['images'] != null ? List<String>.from(json['images']) : null,
      beforeimages: json['before_images'] != null
          ? List<String>.from(json['before_images'])
          : null,
      note: json['note']?.toString() ?? '',
      updatedAt: json['updated_at']?.toString() ?? '',
      beforeImagesUploadedAt: json['before_images_uploaded_at']?.toString(),
      afterImagesUploadedAt: json['after_images_uploaded_at']?.toString(),
    );
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['date'] = date;
    data['status'] = status;
    data['label'] = label;
    data['color'] = color;
    data['images'] = images;
    data['before_images'] = beforeimages;
    data['note'] = note;
    data['updated_at'] = updatedAt;
    data['before_images_uploaded_at'] = beforeImagesUploadedAt;
    data['after_images_uploaded_at'] = afterImagesUploadedAt;
    return data;
  }
}
