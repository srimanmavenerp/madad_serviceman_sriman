// import 'dart:io';
// import 'package:demandium_serviceman/utils/core_export.dart';
// import 'package:get/get.dart';
// import 'package:image_picker/image_picker.dart';

// class CameraButtonSheetCancelledimage extends StatefulWidget {
//   final String bookingId;
//   final bool isSubBooking;

//   const CameraButtonSheetCancelledimage({
//     super.key,
//     required this.bookingId,
//     required this.isSubBooking,
//   });

//   @override
//   State<CameraButtonSheetCancelledimage> createState() =>
//       _CameraButtonSheetCancelledimageState();
// }

// class _CameraButtonSheetCancelledimageState
//     extends State<CameraButtonSheetCancelledimage> {
//   final List<XFile> _pickedImages = [];

//   /// Pick image from camera or gallery
//   Future<void> _pickImage({required bool isCamera}) async {
//     if (_pickedImages.length >= 5) {
//       Get.snackbar('Info', 'You can select up to 5 images only',
//           snackPosition: SnackPosition.BOTTOM);
//       return;
//     }

//     final XFile? pickedFile = await ImagePicker().pickImage(
//       source: isCamera ? ImageSource.camera : ImageSource.gallery,
//       imageQuality: 50,
//     );

//     if (pickedFile != null) {
//       setState(() {
//         _pickedImages.add(pickedFile);
//       });
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       padding:
//           const EdgeInsets.symmetric(vertical: Dimensions.paddingSizeLarge),
//       decoration: BoxDecoration(
//         borderRadius: const BorderRadius.vertical(
//             top: Radius.circular(Dimensions.radiusExtraLarge)),
//         color: Theme.of(context).cardColor,
//       ),
//       child: Column(mainAxisSize: MainAxisSize.min, children: [
//         Container(
//           height: 4,
//           width: 50,
//           decoration: BoxDecoration(
//             borderRadius: BorderRadius.circular(Dimensions.radiusDefault),
//             color: Theme.of(context).disabledColor,
//           ),
//         ),
//         const SizedBox(height: Dimensions.paddingSizeLarge),

//         // Title
//         Text(
//           "Cancellation Images",
//           style: robotoBold.copyWith(
//             fontSize: Dimensions.fontSizeLarge,
//             color: Theme.of(context)
//                 .textTheme
//                 .bodyLarge
//                 ?.color
//                 ?.withValues(alpha: 0.8),
//           ),
//         ),
//         const SizedBox(height: Dimensions.paddingSizeSmall),

//         // Hint
//         Padding(
//           padding: const EdgeInsets.symmetric(
//               horizontal: Dimensions.paddingSizeDefault * 2),
//           child: Text(
//             "You can select up to 5 images related to cancellation.",
//             style: robotoRegular.copyWith(
//               color: Theme.of(context)
//                   .textTheme
//                   .bodySmall
//                   ?.color
//                   ?.withValues(alpha: 0.7),
//             ),
//             textAlign: TextAlign.center,
//           ),
//         ),
//         const SizedBox(height: Dimensions.paddingSizeLarge),

//         // Show picked images horizontally
//         _pickedImages.isEmpty
//             ? const SizedBox()
//             : Padding(
//                 padding: const EdgeInsets.symmetric(horizontal: 5),
//                 child: SizedBox(
//                   height: 100,
//                   child: ListView.builder(
//                     scrollDirection: Axis.horizontal,
//                     itemCount: _pickedImages.length,
//                     itemBuilder: (context, index) {
//                       return Stack(
//                         children: [
//                           Container(
//                             margin: const EdgeInsets.symmetric(horizontal: 5),
//                             child: Image.file(
//                               File(_pickedImages[index].path),
//                               width: 100,
//                               height: 100,
//                               fit: BoxFit.cover,
//                             ),
//                           ),
//                           Positioned(
//                             top: 0,
//                             right: 0,
//                             child: GestureDetector(
//                               onTap: () {
//                                 setState(() {
//                                   _pickedImages.removeAt(index);
//                                 });
//                               },
//                               child:
//                                   const Icon(Icons.cancel, color: Colors.red),
//                             ),
//                           ),
//                         ],
//                       );
//                     },
//                   ),
//                 ),
//               ),

//         const SizedBox(height: Dimensions.paddingSizeLarge),

//         // Camera + Gallery buttons
//         Row(
//           mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//           children: [
//             _buildPickButton(
//               icon: Image.asset(Images.upload, width: 30),
//               label: 'Upload Image',
//               isCamera: false,
//             ),
//             _buildPickButton(
//               icon: Icon(Icons.camera_alt_outlined,
//                   size: 30, color: Theme.of(context).primaryColor),
//               label: 'Take Photo',
//               isCamera: true,
//             ),
//           ],
//         ),

//         const SizedBox(height: Dimensions.paddingSizeLarge),

//         // Save & Continue
//         Padding(
//           padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 10),
//           child: SizedBox(
//             width: double.infinity,
//             height: 50,
//             child: ElevatedButton(
//               onPressed: () {
//                 // Convert XFile -> File
//                 List<File> selectedFiles =
//                     _pickedImages.map((xfile) => File(xfile.path)).toList();
//                 Get.back(result: selectedFiles); // <-- Return selected images
//               },
//               style: ElevatedButton.styleFrom(
//                 backgroundColor: Theme.of(context).primaryColor,
//                 shape: RoundedRectangleBorder(
//                   borderRadius: BorderRadius.circular(12),
//                 ),
//                 elevation: 3,
//               ),
//               child: Text(
//                 'Save & Continue',
//                 style: robotoBold.copyWith(
//                   color: Colors.white,
//                   fontSize: Dimensions.fontSizeLarge,
//                 ),
//               ),
//             ),
//           ),
//         ),
//       ]),
//     );
//   }

//   Widget _buildPickButton(
//       {required Widget icon, required String label, required bool isCamera}) {
//     return InkWell(
//       onTap: () => _pickImage(isCamera: isCamera),
//       child: Column(
//         children: [
//           Container(
//             padding: const EdgeInsets.all(Dimensions.paddingSizeLarge),
//             decoration: BoxDecoration(
//               color: Theme.of(context).primaryColor.withValues(alpha: 0.1),
//               borderRadius: BorderRadius.circular(Dimensions.radiusDefault),
//             ),
//             child: icon,
//           ),
//           const SizedBox(height: Dimensions.paddingSizeSmall),
//           Text(
//             label,
//             style: robotoRegular.copyWith(
//               color: Theme.of(context)
//                   .textTheme
//                   .bodySmall
//                   ?.color
//                   ?.withValues(alpha: 0.7),
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }
